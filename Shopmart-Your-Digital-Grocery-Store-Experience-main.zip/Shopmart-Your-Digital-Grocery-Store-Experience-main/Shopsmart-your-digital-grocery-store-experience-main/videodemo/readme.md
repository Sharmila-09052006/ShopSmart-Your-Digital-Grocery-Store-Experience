PROJECT VIDEO LINKS 

USER INTERFACE LINK
https://drive.google.com/file/d/1Ff161x9udQSAabAjljnMdsn_wi_U8iA5/view?usp=sharing
ADMIN INTERFACE LINK
https://drive.google.com/file/d/1YVwmXOhiFWTxygLIyJ9kEVCnb7MmLONK/view?usp=sharing
